/************************************************************************
// File lwpconio.h - INCOMPLETE patch to conio.h
// Copyright (C) 1997 Paolo De Marino
//
// Original Source Code by Sengan Short (sengan.short@durham.ac.uk)
// and Josh Turpen (snarfy@goodnet.com).
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version,
//  with the only exception that all the people in the THANKS file
//  must receive credit.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Library General Public License for more details.
//
//  You should have received a copy of the GNU Library General Public
//  License along with this library; see the file COPYING.LIB.
//  If not, write to the Free Software Foundation, Inc., 675 Mass Ave,
//  Cambridge, MA 02139, USA.
//
//  For contacting the author send electronic mail to
//     paolodemarino@usa.net
//
//  Or paper mail to
//
//     Paolo De Marino
//     Via Donizetti 1/E
//     80127 Naples
//     Italy
//
// History: see history.txt
************************************************************************/
#ifndef __LWP_CONIO_H__
#define __LWP_CONIO_H__

#if defined(printf) && defined(__LWP_INCLUDE_STDIO_H_)
   #undef printf
	#include <conio.h>
	#define printf _lwp_printf
#else
	#include <conio.h>
#endif
extern int _lwp_enable;
#ifdef __cplusplus
extern "C" {
#endif

#ifndef __dj_ENFORCE_ANSI_FREESTANDING
#ifndef __STRICT_ANSI__
#ifndef _POSIX_SOURCE

#ifdef __DJGPP__
	#define ATTR  __attribute__((unused))
#else
	#define ATTR
#endif
#define PROTO(x) x ATTR; x

PROTO(__inline__ static char* _lwp_cgets(char *_str))
{ char* result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = cgets(_str);
  _lwp_enable = tmp;
  return result;
 }
#define cgets _lwp_gets

PROTO( __inline__ static void _lwp_clreol(void) )
 { 
 volatile int tmp;
 tmp = _lwp_enable; 
 _lwp_enable = 1;
 clreol();
 _lwp_enable = tmp;
 }
#define clreol _lwp_clreol

PROTO( __inline__ static void _lwp_clrscr(void) )
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 clrscr();
 _lwp_enable = tmp;
 }
#define clrscr _lwp_clrscr

PROTO( __inline__ static int _lwp__conio_kbhit(void) )
{ volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = _conio_kbhit();
  _lwp_enable = tmp;
  return result; }
#define _conio_kbhit _lwp__conio_kbhit

#ifndef __DJGPP__
#define cprintf #error "Not done in LWP_CONIO.h"
#else
#define cprintf(format, args...) 	\
  {											\
		  int res,tmp = _lwp_enable;	\
		  _lwp_enable = 1;				\
		  res = cprintf(format , ##args); \
		  _lwp_enable = 0;				\
		  res;								\
  }
#endif
/*int   cprintf(const char *_format, ...) __attribute__((format(printf,1,2)));*/

PROTO(__inline__ static int _lwp_cputs(const char *_str) )
{ volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = cputs(_str);
  _lwp_enable = tmp; 
  return result;
 }
#define cputs _lwp_cputs

/*int     cscanf(const char *_format, ...) __attribute__((format(scanf,1,2)));*/
#ifndef __DJGPP__
#define cscanf #error "Not done in LWP_CONIO.h"
#else
#define cscanf(format, args...) 	\
  {											\
		  int res,tmp = _lwp_enable;	\
		  _lwp_enable = 1;				\
		  res = cscanf(format , ##args); \
		  _lwp_enable = 0;				\
		  res;								\
  }
#endif
/*int   cprintf(const char *_format, ...) __attribute__((format(printf,1,2)));*/

PROTO(__inline__ static void _lwp_delline(void))
{ 
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  delline(); 
  _lwp_enable = tmp;
  }
#define delline _lwp_delline

PROTO(__inline__ static int _lwp_getch(void))
{ volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = getch();
  _lwp_enable = tmp;
  return result;
  }
#define getch _lwp_getch

PROTO(__inline__ static int _lwp_getche(void))
{ volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = getche();
  _lwp_enable = tmp;
  return result;
 }
#define getche _lwp_getche
PROTO(
__inline__ static int
     _lwp_gettext(int _left, int _top, int _right, int _bottom, void *_destin)
)
{
  volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = gettext(_left, _top, _right, _bottom, _destin);
  _lwp_enable = tmp;
  return result; 
  }
#define gettext _lwp_gettext

PROTO(__inline__ static void _lwp_gettextinfo(struct text_info *_r))
{ 
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  gettextinfo(_r);
  _lwp_enable = tmp;
}
#define gettextinfo _lwp_gettextinfo

PROTO(__inline__ static void _lwp_gotoxy(int _x, int _y))
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 gotoxy(_x,_y); 
 _lwp_enable = tmp;
 }
#define gotoxy _lwp_gotoxy

PROTO(__inline__ static void _lwp_gppconio_init(void))
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 gppconio_init(); 
 _lwp_enable = tmp;
}
#define gppconio_init _lwp_gppconio_init

PROTO(__inline__ static void _lwp_highvideo(void))
 { 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 highvideo();
 _lwp_enable = tmp;
 }
#define highvideo _lwp_highvideo

PROTO(__inline__ static void _lwp_insline(void))
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 insline();
 _lwp_enable = tmp; 
 }
#define insline _lwp_insline

PROTO(__inline__ static void _lwp_lowvideo(void))
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 lowvideo();
 _lwp_enable = tmp; 
 }
#define lowvideo _lwp_lowvideo
PROTO(
__inline__ static int _lwp_movetext(int _left, int _top, int _right,
                                    int _bottom, int _destleft, int _desttop)
)
{ volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = movetext(_left, _top, _right, _bottom, _destleft, _desttop);
  _lwp_enable = tmp; 
  return result; 
 }
#define movetext _lwp_movetext

PROTO(__inline__ static void _lwp_normvideo(void))
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 normvideo(); 
 _lwp_enable = tmp;
 }
#define normvideo _lwp_normvideo

PROTO(__inline__ static int _lwp_putch(int _c))
{
  volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = putch(_c);
  _lwp_enable = tmp;
  return result;
 }
#define putch _lwp_putch
PROTO(
__inline__ static
  int _lwp_puttext(int _left, int _top, int _right, int _bottom, void *_source)
)
{ 
  volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = puttext(_left, _top, _right, _bottom, _source);
  _lwp_enable = tmp;
  return result;
  }
#define puttext _lwp_puttext

PROTO(__inline__ static void _lwp__setcursortype(int _type))
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1; 
 _setcursortype(_type); 
 _lwp_enable = tmp;
}
#define _setcursortype _lwp__setcursortype

PROTO(__inline__ static void _lwp__set_screen_lines(int _nlines))
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 _set_screen_lines(_nlines); 
 _lwp_enable = tmp;
 }
#define _set_screen_lines _lwp__set_screen_lines

PROTO(__inline__ static void _lwp_textattr(int _attr) )
{
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  textattr(_attr); 
  _lwp_enable = tmp;
}
#define textattr _lwp_textattr

PROTO( __inline__ static void _lwp_textbackground(int _colour) )
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 textbackground(_colour); 
 _lwp_enable = tmp;
}
#define textbackground _lwp_textbackground

PROTO( __inline__ static void _lwp_textcolor(int _colour) )
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 textcolor(_colour); 
 _lwp_enable = tmp; 
 }
#define textcolor _lwp_textcolor

PROTO( __inline__ static void _lwp_textmode(int _mode) )
{ 
 volatile int tmp;
 tmp = _lwp_enable;
 _lwp_enable = 1;
 textmode(_mode); 
 _lwp_enable = tmp;
 }
#define textmode _lwp_textmode

PROTO( __inline__ static int _lwp_ungetch(int _char) )
{ volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = ungetch(_char);
  _lwp_enable = tmp;
  return result; 
  }
#define ungetch _lwp_ungetch

PROTO( __inline__ static int _lwp_wherex( void ) )
{ 
  volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = wherex();
  _lwp_enable = tmp;
  return result;
  }
#define wherex _lwp_wherex

PROTO( __inline__ static int _lwp_wherey( void ) )
{ 
  volatile int result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  result = wherey();
  _lwp_enable = tmp;
  return result; 
  }
#define wherey _lwp_wherey
PROTO(
__inline__ static void _lwp_window(int _left, int _top, int _right, int _bottom)
)
{ 
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  window(_left, _top, _right, _bottom);
  _lwp_enable = tmp;
 }
#define window _lwp_window

#define kbhit _conio_kbhit /* Who ever includes gppconio.h probably
                              also wants _conio_kbhit and not kbhit
                              from libc */

#endif /* !_POSIX_SOURCE */
#endif /* !__STRICT_ANSI__ */
#endif /* !__dj_ENFORCE_ANSI_FREESTANDING */

#ifdef __cplusplus
}
#endif

#undef ATTR
#undef PROTO

#endif /* !__LWP_CONIO_H__ */
