/************************************************************************
// File lwppc.h - INCOMPLETE patch to pc.h
// Copyright (C) 1997 Paolo De Marino
//
// Original Source Code by Sengan Short (sengan.short@durham.ac.uk)
// and Josh Turpen (snarfy@goodnet.com).
//
//
//  This library is free software; you can redistribute it and/or
//  modify it under the terms of the GNU Library General Public
//  License as published by the Free Software Foundation; either
//  version 2 of the License, or (at your option) any later version,
//  with the only exception that all the people in the THANKS file
//  must receive credit.
//
//  This library is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
//  Library General Public License for more details.
//
//  You should have received a copy of the GNU Library General Public
//  License along with this library; see the file COPYING.LIB.
//  If not, write to the Free Software Foundation, Inc., 675 Mass Ave,
//  Cambridge, MA 02139, USA.
//
//  For contacting the author send electronic mail to
//     paolodemarino@usa.net
//
//  Or paper mail to
//
//     Paolo De Marino
//     Via Donizetti 1/E
//     80127 Naples
//     Italy
//
// History: see history.txt
************************************************************************/
#ifndef __LWP_PC_H__
#define __LWP_PC_H__
#include <pc.h>

#ifdef __DJGPP__
	#define ATTR  __attribute__((unused))
#else
	#define ATTR
#endif
#define PROTO(x) x ATTR; x


#ifdef __cplusplus
extern "C" {
#endif

/* A lot missing in here */
PROTO(__inline__ static int _lwp_kbhit(void))
{
  volatile int _lwp_result;
  volatile int tmp;
  tmp = _lwp_enable;
  _lwp_enable = 1;
  _lwp_result = kbhit(); 
  _lwp_enable = tmp;
  return _lwp_result;
  }
#undef kbhit
#define kbhit _lwp_kbhit

#ifdef __cplusplus
}
#endif

#undef ATTR
#undef PROTO

#endif /*__LWP_PC_H__*/
