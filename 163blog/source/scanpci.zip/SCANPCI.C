#include <stdio.h>
#include <dpmi.h>

typedef unsigned long      UDWORD;
typedef unsigned short int UWORD;

int main() {
  UDWORD i, busNo, deviceNo, funcNo, regVal, retVal;
  UWORD  vendorID, devID, class1, class2, class3;
  
  __dpmi_regs r;

  r.x.ax = 0xb101;
  __dpmi_int(0x1a, &r);
  i = r.x.flags;
  if ((i & 0x01) == 0) printf("\nSupport PCI BIOS");
  else printf("\nNot Support PCI BIOS");
  
  printf("\nNo.  Vendor/Device  Bus No.  Dev No.  Func No.  Class");
  i = 0;
  for (busNo = 0; busNo < 5; busNo++) {                 // bus No
    for(deviceNo = 0; deviceNo < 32; deviceNo++) {      // device no
      for (funcNo = 0; funcNo < 8; funcNo++) {          // Function No
        //j = 0x80000000 + i * 2048;
        regVal = 0x80000000                             // bit31 ʹ��
                 + (busNo << 16)                        // Bus No
                 + (deviceNo << 11)                     // Device No
                 + (funcNo << 8);                       // Function No
        outportl(0xCF8, regVal);
        retVal = inportl(0xCFC);                        // �õ����ÿռ�ƫ��Ϊ0��˫��
        if (retVal != 0xffffffff) {                     // �豸����
          i++;
          vendorID = retVal & 0xffff;                   // �õ���Ӧ�̴���
          devID    = (retVal >> 16) & 0xffff;           // �õ��豸����
          regVal  += 0x08;                              // �õ����ÿռ�ƫ��Ϊ08H��˫��
          outportl(0xCF8, regVal);
          retVal   = inportl(0xCFC);
          retVal   = retVal >> 8;                        // �˵��汾��
          class3   = retVal & 0x0FF;                     // �õ������������
          class2   = (retVal >> 8) &0x0FF;
          class1   = (retVal >> 8) &0x0FF;
          printf("\n%02d   %04x/%04x       %02x       %02x       %02x      %02x-%02x-%02x",
                 i, vendorID, devID, busNo, deviceNo, funcNo, class1, class2, class3);
          if (funcNo == 0) {                          // ����ǵ������豸�����ٲ�funcNo>0���豸
            regVal = (regVal & 0xFFFFFFF0) + 0x0C;
            outportl(0xCF8, regVal);
            retVal = inportl(0xCFC);
            retVal = retVal >> 16;
            if ((retVal & 0x80) == 0) funcNo = 8;
          }
        }
      }
    }
  }
  return 0;
}
